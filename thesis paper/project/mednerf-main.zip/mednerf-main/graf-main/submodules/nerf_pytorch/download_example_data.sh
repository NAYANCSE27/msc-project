wget https://people.eecs.berkeley.edu/~bmild/nerf/tiny_nerf_data.npz
mkdir -p data
cd data
wget https://people.eecs.berkeley.edu/~bmild/nerf/nerf_example_data.zip
unzip nerf_example_data.zip
cd ..
