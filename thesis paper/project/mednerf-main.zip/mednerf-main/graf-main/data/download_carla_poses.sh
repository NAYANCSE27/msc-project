mkdir -p ./carla
cd ./carla
wget https://s3.eu-central-1.amazonaws.com/avg-projects/graf/data/carla_poses.zip
unzip carla_poses.zip
cd ..