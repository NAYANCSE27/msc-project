wget https://s3.eu-central-1.amazonaws.com/avg-projects/graf/data/carla.zip
unzip carla.zip
cd ..
